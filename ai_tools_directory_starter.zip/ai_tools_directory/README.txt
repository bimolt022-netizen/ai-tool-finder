AI TOOL FINDER — STARTER WEBSITE

Included:
- Responsive dark AI tools directory homepage
- Search, category filters, sorting and saved/favourite tools
- Tool detail dialog with official provider links
- Starter privacy and disclaimer pages

HOW TO PREVIEW:
Open index.html in a browser.

HOW TO PUBLISH FREE WITH NETLIFY:
1. Create a Netlify account at https://www.netlify.com/
2. In the Netlify dashboard choose Add new site / Deploy manually (wording may change).
3. Drag the unzipped website folder contents into the deploy area, or connect a Git repository.
4. Netlify will assign a free *.netlify.app address.
5. Test the site on mobile and desktop.

BEFORE PUBLIC LAUNCH:
- Replace AI Tool Finder with your chosen brand name.
- Replace hello@example.com in index.html, privacy.html and disclaimer.html.
- Verify each provider URL, feature description, pricing and free-plan limits.
- Add only tools you have checked; do not claim “verified” or “expert reviewed” without actually doing that work.
- Add a real About page and complete privacy/cookie disclosures if you add analytics, ads, forms or affiliate tracking.
- Add affiliate links only after joining each program and disclose them clearly.
- Do not assume AdSense or affiliate approval is guaranteed.
- Add your own original reviews, screenshots (where permitted), testing notes and comparison criteria.
- Keep the directory current; remove dead links and update changed pricing.

The starter tool list is illustrative. Provider names and trademarks belong to their owners.
